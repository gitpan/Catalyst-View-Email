package # Hide me.
    TestApp::View::TT;

use strict;
eval "use base 'Catalyst::View::TT';";

1;
