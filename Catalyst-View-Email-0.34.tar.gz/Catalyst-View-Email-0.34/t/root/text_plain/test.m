<%args>
$time
$email
</%args>

I am plain text.  I have no style.

I was sent to <% $email->{to} %> on <% $time %>
